import { IVehicle } from "./IVehicle";
// Para utilizar o método de manutenção os 
// objetos precisam implementar IVehicle
export default class Garage{


   public carCollection: IVehicle[] = [];

   public maintenance(car: IVehicle){
    //quero buscar informações de manutenção
    let seats: number = car.getSeats();
    let manual: string = car.getReport();

   }


}
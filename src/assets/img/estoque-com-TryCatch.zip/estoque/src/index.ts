// import CollectiveCar from "./CollectiveCar";
// import Garage from "./Garage";
// import TurismCar from "./TurismCar";

import Conta from "./excecao/Conta";
import TesteErro from "./excecao/TesteErro";

// let busao: CollectiveCar = new CollectiveCar();
// let fusca: TurismCar = new TurismCar();
// let garagem: Garage = new Garage();

// garagem.carCollection.push(busao);
// garagem.carCollection.push(fusca);

// for (let index = 0; index < garagem.carCollection.length; index++) {
//     const element = garagem.carCollection[index];
//     //polimorfismo!!!!
//     console.log(element.getReport());
// }

// let conta = new Conta();
// conta.deposita(100);
// conta.saca(400);
let teste = new TesteErro();
teste.testeDeErro();
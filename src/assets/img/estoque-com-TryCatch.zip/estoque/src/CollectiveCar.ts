import { IVehicle } from "./IVehicle";

export default class CollectiveCar implements IVehicle{
    getReport(): string {
        return "trata-se de um onibus";
    }
    getSeats(): number {
        return 50;
    }

    public getTicket(): number{
        //regras
        return 3;
    }
}
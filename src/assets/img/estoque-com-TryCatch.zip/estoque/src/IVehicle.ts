export interface IVehicle{

    getReport(): string;
    getSeats(): number;
   

}
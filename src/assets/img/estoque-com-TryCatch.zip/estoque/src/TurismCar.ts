import { IVehicle } from "./IVehicle";

export default class TurismCar implements IVehicle{
    
    getReport(): string {
        return "trata-se de um carro de passeio";
    }
    getSeats(): number {
        return 5;
    }

}
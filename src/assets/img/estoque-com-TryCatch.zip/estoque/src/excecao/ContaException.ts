import Conta from "./Conta";

export default class ContaException extends Error{

    constructor(conta: Conta, s: string){
       super(s + "O saldo atual é: "+ conta.getSaldo());
    }
}
import Conta from "./Conta";
import ContaException from "./ContaException";

export default class TesteErro{

   private conta = new Conta();

  public testeDeErro():void{
    
    try {
        this.conta.deposita(500);
        this.conta.saca(1200);
    } catch (error: any) {
        console.log("deu ruim"+error)
    }
    
  }


}
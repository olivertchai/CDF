import ContaException from "./ContaException";

export default class Conta {

    private saldo: number = 0;

    public saca(valor: number): void {
        if (this.saldo < valor) {
            console.log("saldo insuficiente " + this.saldo);
            throw new ContaException(this, "saldo insuficiente");
        } else {
            this.saldo -= valor;
            console.log("saque executado com sucesso")
        }
    }
    public deposita(valor: number): void {
        this.saldo += valor;
    }
    public getSaldo(): number{
        return this.saldo;
    }


}